*******************************************************
* SIMULACIÓN - LALIBERTÉ (2021)
* 06_ej4_sorting.do
*
* EJERCICIO 4: cuando las familias eligen el lado
*
* Las familias con family_ability alta que habían quedado del
* lado malo se reubican del lado de la escuela buena. Rompe la
* no manipulación de la running variable.
*
* No se sortea ningún número nuevo. Se recuperan los errores
* del proceso generador original y se vuelven a usar, de modo
* que lo único que cambia respecto de la simulación base es la
* ubicación de las familias. Por eso este archivo no necesita
* semilla y el contraste con la corrida base es limpio.
*******************************************************

clear all
set more off

use "data/datos_simulados.dta", clear


*******************************************************
* 0. RESULTADOS DE REFERENCIA, ANTES DE MANIPULAR
*******************************************************

quietly reg high_quality_school ///
    highside distance distance_high female immigrant
scalar fs_base = _b[highside]

quietly reg years_education ///
    highside distance distance_high female immigrant
scalar rf_base = _b[highside]

scalar iv_base = rf_base/fs_base

display "----------------------------------------"
display "REFERENCIA (simulación base)"
display "Primera etapa  = " fs_base
display "Forma reducida = " rf_base
display "RD-IV          = " iv_base
display "----------------------------------------"


*******************************************************
* 1. RECUPERAR LOS ERRORES DEL DGP ORIGINAL
*
* latent_school  = -0.8 + 1.5*highside + 0.55*ability + e1
* years_education = 12 + 0.60*escuela + 0.80*ability
*                   + 0.15*female + e2
*******************************************************

gen double e_latente = latent_school ///
    - (-0.8 + 1.5*highside + 0.55*family_ability)

gen double e_outcome = years_education ///
    - (12 + 0.60*high_quality_school ///
         + 0.80*family_ability + 0.15*female)

label variable e_latente "Error del índice latente de escuela"
label variable e_outcome "Error del resultado educacional"


*******************************************************
* 2. PARTE (a): LAS FAMILIAS DE ALTA HABILIDAD CRUZAN
*******************************************************

* Guardamos la ubicación original para medir cuántas se mueven
gen byte highside_orig = highside

* Las familias con habilidad alta que estaban del lado malo
* se reubican del lado bueno, a la misma distancia del límite
replace distance = -distance if family_ability > 0.8 & distance < 0

replace highside      = (distance >= 0)
replace distance_high = distance*highside

gen byte reubicada = (highside == 1 & highside_orig == 0)

display "Fracción de la muestra reubicada:"
summarize reubicada

tab highside_orig highside

*-----------------------------------------------------
* 2.1 Regenerar escuela y resultado con las reglas originales
*-----------------------------------------------------

replace latent_school = ///
      -0.8 ///
    + 1.5*highside ///
    + 0.55*family_ability ///
    + e_latente

replace high_quality_school = (latent_school > 0)

replace years_education = ///
      12 ///
    + 0.60*high_quality_school ///
    + 0.80*family_ability ///
    + 0.15*female ///
    + e_outcome

capture mkdir "data"
save "data/ej4_sorting.dta", replace

*-----------------------------------------------------
* 2.2 Test de densidad: ¿hay acumulación en el umbral?
*-----------------------------------------------------

rddensity distance, c(0)

* La tabla que imprime rddensity trae el estadístico T y su
* valor p. Dejamos además el ereturn completo en el log, para
* poder citar el número exacto en la pauta.
ereturn list

* Conteo simple alrededor del umbral, para leer el salto a ojo
count if distance >= -0.1 & distance < 0
local n_izq = r(N)
count if distance >= 0 & distance < 0.1
local n_der = r(N)
display "Observaciones en [-0,1 ; 0)  = " `n_izq'
display "Observaciones en [0 ; 0,1)   = " `n_der'
display "Razón derecha / izquierda    = " `n_der'/`n_izq'


*******************************************************
* 3. PARTE (b): REESTIMAR EL RD-IV SOBRE DATOS MANIPULADOS
*******************************************************

reg high_quality_school ///
    highside distance distance_high female immigrant

scalar fs_sort = _b[highside]

reg years_education ///
    highside distance distance_high female immigrant

scalar rf_sort = _b[highside]

ivregress 2sls years_education ///
    female immigrant ///
    distance distance_high ///
    (high_quality_school = highside)

estat firststage

scalar iv_sort = _b[high_quality_school]

display "----------------------------------------"
display "EJERCICIO 4 (b) - RD-IV CON SORTING"
display "----------------------------------------"
display "Verdad                = 0.60"
display "Primera etapa  base = " fs_base "   con sorting = " fs_sort
display "Forma reducida base = " rf_base "   con sorting = " rf_sort
display "RD-IV          base = " iv_base "   con sorting = " iv_sort
display "Razón respecto de la verdad = " iv_sort/0.60
display "----------------------------------------"


*******************************************************
* 4. PARTE (c): POR QUÉ EL BALANCE NO LO DETECTA
*
* Las covariables observadas siguen equilibradas en la
* frontera, porque el sorting ocurrió sobre una variable que
* el investigador no mide. La habilidad familiar, en cambio,
* salta de manera brutal, pero no está en ninguna tabla de
* balance posible.
*******************************************************

display "----------------------------------------"
display "BALANCE DE COVARIABLES"
display "----------------------------------------"

foreach v in female immigrant {
    display "--- `v' (observable) ---"
    reg `v' highside distance distance_high, vce(robust)
    display "Salto en `v' = " _b[highside] ///
            "   t = " _b[highside]/_se[highside]
}

display "--- family_ability (NO observable) ---"
reg family_ability highside distance distance_high, vce(robust)
display "Salto en family_ability = " _b[highside] ///
        "   t = " _b[highside]/_se[highside]

*-----------------------------------------------------
* 4.1 Donut-hole: tampoco arregla el problema
*
* Las familias reubicadas quedan repartidas por todo el lado
* positivo, no en una banda angosta junto al umbral, de modo
* que sacar las observaciones más cercanas no limpia nada.
*-----------------------------------------------------

display "----------------------------------------"
display "DONUT-HOLE"
display "----------------------------------------"

foreach d in 0.05 0.10 0.20 {
    quietly ivregress 2sls years_education ///
        female immigrant distance distance_high ///
        (high_quality_school = highside) ///
        if abs(distance) > `d'
    display "Donut de `d': RD-IV = " _b[high_quality_school]
}
