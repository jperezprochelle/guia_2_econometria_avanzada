*******************************************************
* SIMULACIÓN - LALIBERTÉ (2021)
* 00_master.do
*
* Ejecuta la simulación completa de la Guía 2.
*
* CÓMO CORRERLO EN CUALQUIER COMPUTADOR
* -------------------------------------
* Opción A (recomendada): abra Stata, sitúese en la carpeta
*   simulacion_laliberte y ejecute
*       do 00_master.do
*
* Opción B: escriba la ruta completa de la carpeta en el
*   local -ruta- de la línea marcada más abajo y ejecute
*   este archivo desde donde sea.
*
* No hay que editar nada más. Las carpetas data/ y figures/
* se crean solas y su contenido se regenera por completo.
*******************************************************

clear all
set more off
set varabbrev off

*******************************************************
* 0. DIRECTORIO DE TRABAJO
*******************************************************

* ÚNICA LÍNEA EDITABLE. Déjela vacía si usa la opción A.
local ruta ""

if "`ruta'" != "" {
    capture cd "`ruta'"
    if _rc {
        display as error "No existe la carpeta indicada en -ruta-."
        exit 170
    }
}

* Verificación: los .do tienen que estar en el directorio actual
capture confirm file "01_simular_datos.do"
if _rc {
    display as error ///
        "No encuentro 01_simular_datos.do en el directorio actual."
    display as error ///
        "Sitúe Stata en la carpeta simulacion_laliberte, o escriba"
    display as error ///
        "la ruta de esa carpeta en el local -ruta- de 00_master.do."
    exit 601
}

display "Directorio de trabajo: " c(pwd)

*******************************************************
* 1. DEPENDENCIAS EXTERNAS
*******************************************************

* rddensity y lpdensity se usan en el Ejercicio 4 (test de
* manipulación de Cattaneo, Jansson y Ma). El resto de la
* simulación usa solo comandos oficiales de Stata.

foreach paquete in rddensity lpdensity {
    capture which `paquete'
    if _rc {
        display "Instalando `paquete' desde SSC..."
        capture noisily ssc install `paquete', replace
    }
    else {
        display "`paquete' ya está instalado."
    }
}

*******************************************************
* 2. CARPETAS DE SALIDA
*******************************************************

capture mkdir "data"
capture mkdir "figures"

*******************************************************
* 3. LOG DE LA CORRIDA COMPLETA
*******************************************************

capture log close _all
log using "salida_completa.txt", text replace

display "======================================================"
display "SIMULACIÓN LALIBERTÉ (2021) - GUÍA 2 ICS 3564"
display "Corrida iniciada: " c(current_date) " " c(current_time)
display "Versión de Stata: " c(stata_version)
display "======================================================"

*******************************************************
* 4. TUTORIAL
*******************************************************

* Semillas: 01 fija 2026, 03 fija 2027, 04 fija 2028 y 05 fija
* 2029. 02 y 06 no sortean ningún número aleatorio, así que no
* necesitan semilla: 02 solo estima sobre la base guardada por
* 01, y 06 reutiliza los errores del proceso generador original.

do "01_simular_datos.do"          // DGP del RD-IV
do "02_rd_iv.do"                  // OLS ingenuo, primera etapa, RD-IV
do "03_movers.do"                 // movers design
do "04_descomposicion.do"         // horse-race escolar / no escolar

*******************************************************
* 5. EJERCICIOS
*******************************************************


do "07_ej2_shock_por_barrio.do"        // Ejercicio 2(b)
do "05_ej3_tratamiento_compuesto.do"   // Ejercicio 3
do "06_ej4_sorting.do"                 // Ejercicio 4

display "======================================================"
display "Corrida terminada: " c(current_date) " " c(current_time)
display "======================================================"

log close
