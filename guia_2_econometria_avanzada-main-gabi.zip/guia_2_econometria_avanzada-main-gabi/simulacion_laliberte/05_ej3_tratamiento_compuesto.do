*******************************************************
* SIMULACIÓN - LALIBERTÉ (2021)
* 05_ej3_tratamiento_compuesto.do
*
* EJERCICIO 3: cuando la frontera mueve algo más que la escuela
*
* (a) Se agrega al proceso generador un canal no escolar
*     delta*highside que también salta en la frontera, con
*     delta = 0,15. Rompe la restricción de exclusión.
* (b) Se construye un grupo placebo expuesto a la misma
*     frontera pero no al canal escolar, análogo a los
*     estudiantes del sistema inglés del paper.
*******************************************************

clear all
set more off


*******************************************************
* PARTE (a): TRATAMIENTO COMPUESTO
*******************************************************

use "data/datos_simulados.dta", clear

scalar delta_true = 0.15

*-----------------------------------------------------
* a.1 Estimaciones de referencia, ANTES de la contaminación
*-----------------------------------------------------

quietly reg high_quality_school ///
    highside distance distance_high female immigrant
scalar fs_base = _b[highside]

quietly reg years_education ///
    highside distance distance_high female immigrant
scalar rf_base = _b[highside]

scalar iv_base = rf_base / fs_base

display "----------------------------------------"
display "REFERENCIA (simulación base)"
display "Primera etapa  = " fs_base
display "Forma reducida = " rf_base
display "RD-IV          = " iv_base
display "----------------------------------------"

*-----------------------------------------------------
* a.2 Predicción algebraica, antes de reestimar
*
* La frontera abre un segundo canal hacia el resultado.
* La forma reducida pasa a estimar rho + delta, la primera
* etapa sigue siendo varsigma, y el RD-IV, que es el cociente
* de ambas, converge a pi + delta/varsigma.
*-----------------------------------------------------

scalar rf_pred = rf_base + delta_true
scalar iv_pred = iv_base + delta_true/fs_base

display "Predicción: forma reducida = " rf_pred
display "Predicción: RD-IV          = " iv_pred
display "Sesgo esperado             = " delta_true/fs_base

*-----------------------------------------------------
* a.3 Un canal no escolar que también salta en la frontera
*
* Se suma delta*highside al resultado ya generado. No se
* sortea ningún número nuevo, de modo que la única diferencia
* respecto de la simulación base es el canal agregado.
*-----------------------------------------------------

replace years_education = years_education + delta_true*highside

* Primera etapa: no debería moverse
reg high_quality_school ///
    highside distance distance_high female immigrant

scalar fs_comp = _b[highside]

* Forma reducida: debería subir exactamente delta
reg years_education ///
    highside distance distance_high female immigrant

scalar rf_comp = _b[highside]

* RD-IV contaminado
ivregress 2sls years_education ///
    female immigrant ///
    distance distance_high ///
    (high_quality_school = highside)

estat firststage

scalar iv_comp = _b[high_quality_school]

*-----------------------------------------------------
* a.4 Verificación de la predicción
*-----------------------------------------------------

display "----------------------------------------"
display "EJERCICIO 3 (a) - TRATAMIENTO COMPUESTO"
display "----------------------------------------"
display "Primera etapa  base = " fs_base   "   contaminada = " fs_comp
display "Forma reducida base = " rf_base   "   contaminada = " rf_comp
display "RD-IV          base = " iv_base   "   contaminado  = " iv_comp
display "----------------------------------------"
display "RD-IV predicho      = " iv_pred
display "RD-IV estimado      = " iv_comp
display "Diferencia          = " iv_comp - iv_pred
display "Sesgo sobre la verdad (0,60) = " iv_comp - 0.60
display "----------------------------------------"

save "data/ej3_compuesto.dta", replace


*******************************************************
* PARTE (b): GRUPO PLACEBO
*
* Muestra expuesta a la misma frontera y al mismo canal no
* escolar, pero cuya escuela NO depende del lado en que vive.
* Es el análogo del sistema inglés: comparte el entorno
* residencial, no el canal escolar.
*
* Con primera etapa nula por construcción, la forma reducida
* de este grupo estima delta directamente.
*******************************************************

clear all
set seed 2029

set obs 50000

gen id = _n

*-----------------------------------------------------
* b.1 Mismo entorno que la muestra principal
*-----------------------------------------------------

gen family_ability = rnormal(0,1)
gen female    = runiform() < 0.5
gen immigrant = runiform() < 0.20

gen distance      = runiform(-1,1)
gen highside      = (distance >= 0)
gen distance_high = distance*highside

label variable distance "Distancia relativa a la frontera"
label variable highside "Lado de escuela asignada de mayor calidad"

*-----------------------------------------------------
* b.2 Escuela asistida: NO depende de highside
*
* La probabilidad sigue dependiendo de la habilidad familiar,
* de modo que el grupo tiene la misma endogeneidad escolar que
* el resto. Lo único que falta es el canal de la frontera.
*-----------------------------------------------------

gen high_quality_school = ///
    (runiform() < 0.48 + 0.08*family_ability)

label variable high_quality_school ///
    "Asiste a escuela de alta calidad"

*-----------------------------------------------------
* b.3 Resultado, con el mismo canal no escolar
*-----------------------------------------------------

gen years_education = ///
      12 ///
    + 0.60*high_quality_school ///
    + 0.80*family_ability ///
    + 0.15*female ///
    + rnormal(0,1) ///
    + 0.15*highside

label variable years_education "Años de educación"

capture mkdir "data"
save "data/ej3_placebo.dta", replace

*-----------------------------------------------------
* b.4 Primera etapa del grupo placebo: debería ser cero
*-----------------------------------------------------

reg high_quality_school ///
    highside distance distance_high female immigrant, vce(robust)

scalar fs_placebo = _b[highside]
scalar t_fs_placebo = _b[highside]/_se[highside]

*-----------------------------------------------------
* b.5 Forma reducida del grupo placebo: estima delta
*-----------------------------------------------------

reg years_education ///
    highside distance distance_high female immigrant, vce(robust)

scalar rf_placebo = _b[highside]
scalar se_placebo = _se[highside]
scalar t_placebo  = _b[highside]/_se[highside]

display "----------------------------------------"
display "EJERCICIO 3 (b) - GRUPO PLACEBO"
display "----------------------------------------"
display "Primera etapa placebo  = " fs_placebo ///
        "   (t = " t_fs_placebo ")"
display "Forma reducida placebo = " rf_placebo
display "Error estándar robusto = " se_placebo
display "Estadístico t          = " t_placebo
display "delta verdadero        = 0.15"
display "----------------------------------------"
