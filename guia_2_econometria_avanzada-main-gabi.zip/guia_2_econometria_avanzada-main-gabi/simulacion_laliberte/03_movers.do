*******************************************************
* SIMULACIÓN - LALIBERTÉ (2021)
* 03_movers.do
*
* Objetivo:
* Simular un movers design y recuperar la tasa causal
* de convergencia hacia el barrio de destino.
*******************************************************

clear all
set more off
set seed 2027

*******************************************************
* 1. CREAR MUESTRA DE MOVERS
*******************************************************

set obs 30000

gen id = _n


*******************************************************
* 2. BARRIOS DE ORIGEN Y DESTINO
*******************************************************

* 20 barrios posibles
gen origin = ceil(runiform()*20)
gen destination = ceil(runiform()*20)

* Evitar que origen = destino
replace destination = mod(destination,20)+1 ///
    if destination == origin

* Calidad estructural de cada barrio
* Creamos una relación ordenada entre barrio y outcome
gen origin_quality = (origin-10.5)/5
gen destination_quality = (destination-10.5)/5


*******************************************************
* 3. DIFERENCIA ENTRE DESTINO Y ORIGEN
*******************************************************

gen delta_quality = destination_quality - origin_quality

label variable delta_quality ///
    "Diferencia de calidad entre destino y origen"


*******************************************************
* 4. EDAD DE MUDANZA
*******************************************************

* Edad entre 7 y 15 años
gen age_move = floor(7 + 9*runiform())

* Años de exposición al destino hasta los 15
gen years_exposure = 16 - age_move

label variable age_move "Edad al momento de mudanza"
label variable years_exposure "Años expuesto al destino"


*******************************************************
* 5. CARACTERÍSTICAS INDIVIDUALES
*******************************************************s

gen female = runiform() < 0.5
gen immigrant = runiform() < 0.20

* Habilidad familiar no observada
gen family_ability = rnormal(0,1)


*******************************************************
* 6. EFECTO CAUSAL VERDADERO DE EXPOSICIÓN
*******************************************************

scalar beta_movers_true = 0.05

* Efecto acumulativo:
* cada año adicional en el destino multiplica
* la diferencia entre destino y origen

gen exposure_effect = ///
    beta_movers_true * years_exposure * delta_quality


*******************************************************
* 7. OUTCOME
*******************************************************

gen years_education = ///
      12 ///
    + 0.5*origin_quality ///
    + exposure_effect ///
    + 0.7*family_ability ///
    + 0.15*female ///
    + rnormal(0,1)


*******************************************************
* 8. ORIGIN x DESTINATION FIXED EFFECT
*******************************************************

egen od_pair = group(origin destination)

label variable od_pair "Par origen-destino"


*******************************************************
* 9. GUARDAR BASE
*******************************************************

capture mkdir "data"

save "data/movers_simulados.dta", replace


*******************************************************
* 10. RESUMEN
*******************************************************

summarize years_education age_move ///
          years_exposure delta_quality

display "Tasa verdadera de convergencia = " ///
        beta_movers_true
		
		
*******************************************************
* ESTIMACIÓN PRINCIPAL - MOVERS DESIGN
*******************************************************

reg years_education ///
    c.years_exposure#c.delta_quality ///
    i.od_pair ///
    i.age_move ///
    female immigrant

scalar beta_movers = ///
    _b[c.years_exposure#c.delta_quality]

display "----------------------------------------"
display "MOVERS DESIGN"
display "Tasa verdadera = " beta_movers_true
display "Tasa estimada  = " beta_movers
display "----------------------------------------"

*******************************************************
* PARAMETRIZACIÓN CON EDAD DE MUDANZA
*******************************************************

gen move_interaction = age_move*delta_quality

reg years_education ///
    move_interaction ///
    i.od_pair ///
    i.age_move ///
    female immigrant

scalar beta_age = _b[move_interaction]

display "Coeficiente usando edad de mudanza = " ///
        beta_age
		
		
*******************************************************
* FIGURA: EFECTOS POR EDAD DE MUDANZA
*******************************************************

* Interactuar delta_quality con cada edad de mudanza
reg years_education ///
    c.delta_quality#i.age_move ///
    i.od_pair ///
    i.age_move ///
    female immigrant

*******************************************************
* Guardar coeficientes
*******************************************************

preserve

clear
set obs 9

gen age_move = _n + 6
gen coef = .
gen se = .

forvalues a = 7/15 {

    local row = `a' - 6

    replace coef = ///
        _b[`a'.age_move#c.delta_quality] ///
        in `row'

    replace se = ///
        _se[`a'.age_move#c.delta_quality] ///
        in `row'
}

gen ci_low  = coef - 1.96*se
gen ci_high = coef + 1.96*se


*******************************************************
* GRÁFICO
*******************************************************

twoway ///
    (rcap ci_low ci_high age_move) ///
    (scatter coef age_move) ///
    (lfit coef age_move), ///
    yline(0, lpattern(dash)) ///
    xtitle("Edad al momento de mudanza") ///
    ytitle("Efecto de la calidad del destino") ///
    title("Efectos de exposición según edad de mudanza") ///
    legend(off)

capture mkdir "figures"

graph export ///
    "figures/movers_age_effects.png", ///
    replace

restore
