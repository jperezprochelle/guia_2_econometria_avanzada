*******************************************************
* SIMULACIÓN - LALIBERTÉ (2021)
* 07_ej2_shock_por_barrio.do
*
* EJERCICIO 2 (b): por qué la descomposición exagera el
* papel de las escuelas.
*
* Este archivo es 04_descomposicion.do con UNA sola
* diferencia, la sección 6. El componente no escolar de cada
* barrio se sortea una vez por barrio y se asigna al mismo
* barrio tanto cuando aparece como origen como cuando aparece
* como destino, en vez de sortearse una vez por estudiante.
*
* Con esa corrección nonschool_origin pasa a ser determinista
* dentro del barrio, los efectos fijos de par la absorben por
* completo igual que a school_origin, y el sesgo de variable
* omitida sobre nonschool_interaction desaparece.
*
* Se conserva la semilla 2028 de 04_descomposicion.do, de modo
* que los estudiantes, los barrios, las edades de mudanza y la
* habilidad familiar son EXACTAMENTE los mismos que en la
* corrida original. Lo único que cambia es la estructura del
* shock no escolar.
*******************************************************

clear all
set more off
set seed 2028


*******************************************************
* 1. CREAR MUESTRA DE MOVERS
*******************************************************

set obs 30000

gen id = _n


*******************************************************
* 2. BARRIOS DE ORIGEN Y DESTINO
*******************************************************

gen origin = ceil(runiform()*20)
gen destination = ceil(runiform()*20)

replace destination = mod(destination,20)+1 ///
    if destination == origin

egen od_pair = group(origin destination)


*******************************************************
* 3. EDAD DE MUDANZA Y EXPOSICIÓN
*******************************************************

gen age_move = floor(7 + 9*runiform())

gen years_exposure = 16 - age_move


*******************************************************
* 4. CARACTERÍSTICAS INDIVIDUALES
*******************************************************

gen female = runiform() < 0.5
gen immigrant = runiform() < 0.20

gen family_ability = rnormal(0,1)


*******************************************************
* 5. CALIDAD ESCOLAR DE ORIGEN Y DESTINO
*******************************************************

gen school_origin = (origin - 10.5)/5
gen school_destination = (destination - 10.5)/5

gen delta_school = ///
    school_destination - school_origin


*******************************************************
* 6. CALIDAD NO ESCOLAR DEL BARRIO   <<< ÚNICA SECCIÓN
*                                         MODIFICADA
*
* Un único shock por barrio, compartido entre origen y
* destino. Antes se sorteaba un rnormal(0,0.15) distinto para
* cada estudiante y para cada rol, de modo que dos personas
* que venían del mismo barrio tenían calidades no escolares
* de origen distintas, lo que es incoherente con la idea de
* que la calidad es un atributo del lugar.
*******************************************************

gen shock_origin      = .
gen shock_destination = .

forvalues b = 1/20 {
    local s = rnormal(0,0.15)
    replace shock_origin      = `s' if origin      == `b'
    replace shock_destination = `s' if destination == `b'
}

gen nonschool_origin = ///
    sin(origin/2) + shock_origin

gen nonschool_destination = ///
    sin(destination/2) + shock_destination

gen delta_nonschool = ///
    nonschool_destination - nonschool_origin

*-----------------------------------------------------
* 6.1 Verificación: ahora no hay variación dentro del barrio
*-----------------------------------------------------

egen sd_dentro_barrio = sd(nonschool_origin), by(origin)

display "Desviación de nonschool_origin dentro de cada barrio"
display "(debe ser cero: la calidad es atributo del lugar)"
summarize sd_dentro_barrio

drop sd_dentro_barrio


*******************************************************
* 7. PARÁMETROS CAUSALES VERDADEROS
*******************************************************

scalar beta_school_true = 0.03
scalar beta_nonschool_true = 0.02
scalar beta_total_true = ///
    beta_school_true + beta_nonschool_true

scalar share_school_true = ///
    beta_school_true / beta_total_true

scalar share_nonschool_true = ///
    beta_nonschool_true / beta_total_true


*******************************************************
* 8. EFECTOS ACUMULATIVOS
*******************************************************

gen school_effect = ///
    beta_school_true * ///
    years_exposure * ///
    delta_school

gen nonschool_effect = ///
    beta_nonschool_true * ///
    years_exposure * ///
    delta_nonschool

gen total_context_effect = ///
    school_effect + nonschool_effect


*******************************************************
* 9. OUTCOME EDUCACIONAL
*******************************************************

gen years_education = ///
      12 ///
    + 0.40*school_origin ///
    + 0.30*nonschool_origin ///
    + total_context_effect ///
    + 0.70*family_ability ///
    + 0.15*female ///
    + rnormal(0,1)


*******************************************************
* 10. INTERACCIONES PARA LA DESCOMPOSICIÓN
*******************************************************

gen school_interaction = ///
    years_exposure * delta_school

gen nonschool_interaction = ///
    years_exposure * delta_nonschool


*******************************************************
* 11. HORSE-RACE
*******************************************************

reg years_education ///
    school_interaction ///
    nonschool_interaction ///
    i.od_pair ///
    i.age_move ///
    female immigrant

scalar beta_school_hat = _b[school_interaction]
scalar beta_nonschool_hat = _b[nonschool_interaction]

scalar se_school_hat = _se[school_interaction]
scalar se_nonschool_hat = _se[nonschool_interaction]


*******************************************************
* 12. EFECTO TOTAL Y SHARES ESTIMADOS
*******************************************************

scalar beta_total_hat = ///
    beta_school_hat + beta_nonschool_hat

scalar share_school_hat = ///
    beta_school_hat / beta_total_hat

scalar share_nonschool_hat = ///
    beta_nonschool_hat / beta_total_hat


*******************************************************
* 13. RESULTADOS
*
* Los valores de la columna "una vez por estudiante" vienen
* de la corrida de 04_descomposicion.do registrada en el log.
*******************************************************

scalar school_viejo = 0.02990681
scalar nonschool_viejo = 0.01639682
scalar total_viejo = 0.04630364
scalar share_viejo = 0.64588473

display " "
display "================================================================"
display "   EJERCICIO 2 (b) - SHOCK NO ESCOLAR POR BARRIO"
display "================================================================"
display " "
display "Componente            Verdad    Por estudiante   Por barrio"
display "----------------------------------------------------------------"
display "Escolar               " %6.4f beta_school_true ///
        "        " %6.4f school_viejo ///
        "         " %6.4f beta_school_hat
display "No escolar            " %6.4f beta_nonschool_true ///
        "        " %6.4f nonschool_viejo ///
        "         " %6.4f beta_nonschool_hat
display "Total                 " %6.4f beta_total_true ///
        "        " %6.4f total_viejo ///
        "         " %6.4f beta_total_hat
display "Participación escolar " %6.4f share_school_true ///
        "        " %6.4f share_viejo ///
        "         " %6.4f share_school_hat
display "----------------------------------------------------------------"
display " "
display "Error estándar del componente escolar    = " se_school_hat
display "Error estándar del componente no escolar = " se_nonschool_hat
display " "
display "Sesgo del componente no escolar, antes = " ///
    nonschool_viejo - beta_nonschool_true
display "Sesgo del componente no escolar, ahora = " ///
    beta_nonschool_hat - beta_nonschool_true
display "================================================================"


*******************************************************
* 14. GUARDAR BASE
*******************************************************

capture mkdir "data"

save "data/ej2_shock_por_barrio.dta", replace
